import { sql } from "drizzle-orm";
import { pgTable, text, varchar, uuid, date, timestamp, boolean, doublePrecision, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email", { length: 255 }).unique().notNull(),
  passwordHash: text("password_hash"),
  role: varchar("role", { length: 20 }).default("user").notNull(),
  emailVerified: boolean("email_verified").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).default(sql`now()`),
});

export const userProfiles = pgTable("user_profiles", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).unique().notNull(),
  slugId: serial("slug_id").notNull().unique(),
  firstName: varchar("first_name", { length: 255 }),
  lastName: varchar("last_name", { length: 255 }),
  phone: varchar("phone", { length: 50 }),
  phoneSecondary: varchar("phone_secondary", { length: 50 }),
  roadAddress: text("road_address"),
  city: varchar("city", { length: 255 }),
  cityCode: varchar("city_code", { length: 50 }),
  country: varchar("country", { length: 255 }),
  countryCode: varchar("country_code", { length: 10 }),
  birthdate: varchar("birthdate", { length: 20 }),
  nationality: varchar("nationality", { length: 255 }),
  profession: varchar("profession", { length: 255 }),
  digiformaId: varchar("digiforma_id", { length: 255 }),
  circleId: varchar("circle_id", { length: 255 }),
  practiceName: varchar("practice_name", { length: 255 }),
  specialties: text("specialties").array(),
  certificationLevel: varchar("certification_level", { length: 100 }),
  bio: text("bio"),
  website: varchar("website", { length: 500 }),
  profileImageUrl: text("profile_image_url"),
  isListed: boolean("is_listed").default(false),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
  updatedAt: timestamp("updated_at", { withTimezone: true }).default(sql`now()`),
});

export const authTokens = pgTable("auth_tokens", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  token: varchar("token", { length: 255 }).unique().notNull(),
  type: varchar("type", { length: 20 }).notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

export const certifications = pgTable("certifications", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  certificationName: varchar("certification_name", { length: 255 }).notNull(),
  issuingBody: varchar("issuing_body", { length: 255 }),
  issuedAt: date("issued_at").notNull(),
  expiresAt: date("expires_at"),
  status: varchar("status", { length: 50 }).default("active"),
  verificationUrl: text("verification_url"),
  certificateImageUrl: text("certificate_image_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

export const trainingRegistrations = pgTable("training_registrations", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }).notNull(),
  programId: varchar("program_id", { length: 50 }).notNull(),
  programName: varchar("program_name", { length: 500 }),
  sessionId: varchar("session_id", { length: 50 }).notNull(),
  sessionDates: text("session_dates"),
  bexioInvoiceId: varchar("bexio_invoice_id", { length: 50 }),
  bexioDocumentNr: varchar("bexio_document_nr", { length: 100 }),
  bexioNetworkLink: text("bexio_network_link"),
  bexioTotal: varchar("bexio_total", { length: 50 }),
  status: varchar("status", { length: 50 }).default("registered"),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

export const activityLogs = pgTable("activity_logs", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
  action: varchar("action", { length: 100 }).notNull(),
  detail: text("detail"),
  targetType: varchar("target_type", { length: 50 }),
  targetId: varchar("target_id", { length: 255 }),
  ipAddress: varchar("ip_address", { length: 100 }),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

export const accredibleCredentials = pgTable("accredible_credentials", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  accredibleCredentialId: varchar("accredible_credential_id", { length: 255 }).unique(),
  recipientEmail: varchar("recipient_email", { length: 255 }).notNull(),
  recipientName: varchar("recipient_name", { length: 500 }),
  groupName: varchar("group_name", { length: 500 }),
  credentialName: varchar("credential_name", { length: 500 }).notNull(),
  description: text("description"),
  issuedAt: timestamp("issued_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  badgeUrl: text("badge_url"),
  certificateUrl: text("certificate_url"),
  url: text("url"),
  userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).default(sql`now()`),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  slugId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCertificationSchema = createInsertSchema(certifications).omit({
  id: true,
  createdAt: true,
});

export const registerSchema = z.object({
  email: z.string().email("Adresse email invalide"),
  password: z.string().min(8, "Le mot de passe doit contenir au moins 8 caractères"),
  firstName: z.string().min(1, "Prénom requis"),
  lastName: z.string().min(1, "Nom requis"),
});

export const loginSchema = z.object({
  email: z.string().email("Adresse email invalide"),
  password: z.string().min(1, "Mot de passe requis"),
});

export const updateProfileSchema = z.object({
  firstName: z.string().min(1, "Prénom requis").optional(),
  lastName: z.string().min(1, "Nom requis").optional(),
  email: z.string().email("Adresse email invalide").optional(),
  phone: z.string().optional(),
  phoneSecondary: z.string().optional(),
  roadAddress: z.string().optional(),
  city: z.string().optional(),
  cityCode: z.string().optional(),
  country: z.string().optional(),
  countryCode: z.string().optional(),
  birthdate: z.string().optional(),
  nationality: z.string().optional(),
  profession: z.string().optional(),
  practiceName: z.string().optional(),
  specialties: z.array(z.string()).optional(),
  certificationLevel: z.string().optional(),
  bio: z.string().optional(),
  website: z.string().optional(),
  profileImageUrl: z.string().optional(),
  isListed: z.boolean().optional(),
  latitude: z.number().optional().nullable(),
  longitude: z.number().optional().nullable(),
});

export const setPasswordSchema = z.object({
  token: z.string().min(1, "Token requis"),
  password: z.string().min(8, "Le mot de passe doit contenir au moins 8 caractères"),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("Adresse email invalide"),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, "Token requis"),
  password: z.string().min(8, "Le mot de passe doit contenir au moins 8 caractères"),
});

export type UserRole = "user" | "student" | "instructor" | "admin";

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type UserProfile = typeof userProfiles.$inferSelect;
export type UpdateProfile = z.infer<typeof updateProfileSchema>;
export type AuthToken = typeof authTokens.$inferSelect;
export const insertTrainingRegistrationSchema = createInsertSchema(trainingRegistrations).omit({
  id: true,
  createdAt: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});

export const insertAccredibleCredentialSchema = createInsertSchema(accredibleCredentials).omit({
  id: true,
  createdAt: true,
});

export type InsertCertification = z.infer<typeof insertCertificationSchema>;
export type Certification = typeof certifications.$inferSelect;
export type InsertTrainingRegistration = z.infer<typeof insertTrainingRegistrationSchema>;
export type TrainingRegistration = typeof trainingRegistrations.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type InsertAccredibleCredential = z.infer<typeof insertAccredibleCredentialSchema>;
export type AccredibleCredential = typeof accredibleCredentials.$inferSelect;

export { replitSessions } from "./models/auth";
