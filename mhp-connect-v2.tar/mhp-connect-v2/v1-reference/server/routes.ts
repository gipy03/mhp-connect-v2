import express from "express";
import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import path from "path";
import fs from "fs";
import multer from "multer";
import { storage, type UserWithProfile, type DirectoryQueryParams } from "./storage";
import { findTraineeByEmail, findAllTraineeIdsByEmail, getTraineeWithSessions, getAllTrainees, getAllTrainingSessions, getAllPrograms, createTrainee as createDigiformaTrainee, addDraftTraineeToSession, getExtranetUrl, DigiformaError } from "./lib/digiforma";
import { fetchArticles, fetchArticleByInternCode, createArticle, findOrCreateContact, createAndSendInvoice } from "./lib/bexio";
import { getCircleMemberToken, getCircleCommunityUrl, listCircleEvents, createCircleEvent, createCircleMember, getCircleSsoRedirectUrl, getCircleHomeFeed, getCircleCommunityEvents, getCircleCommunityMembers, getCircleSpaces, getCircleSpacesList, type CircleAuthToken } from "./lib/circle";
import { sendRegistrationConfirmationEmail } from "./lib/email";
import { geocodeAddress } from "./lib/geocoding";
import {
  updateProfileSchema,
  type UserRole,
} from "@shared/schema";
import cookieParser from "cookie-parser";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";

async function authenticateRequest(req: Request): Promise<{ user: UserWithProfile } | null> {
  const passportUser = req.user as any;

  if (passportUser?.appUserId) {
    const user = await storage.getUserById(passportUser.appUserId);
    if (user) return { user };
  }

  return null;
}

function requireRole(...roles: UserRole[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const auth = await authenticateRequest(req);
    if (!auth) return res.status(401).json({ error: "Unauthorized" });
    if (!roles.includes(auth.user.role as UserRole)) {
      return res.status(403).json({ error: "Forbidden" });
    }
    (req as any).auth = auth;
    next();
  };
}

function formatUserResponse(user: UserWithProfile) {
  return {
    id: user.id,
    email: user.email,
    role: user.role,
    firstName: user.profile?.firstName ?? null,
    lastName: user.profile?.lastName ?? null,
    phone: user.profile?.phone ?? null,
    phoneSecondary: user.profile?.phoneSecondary ?? null,
    roadAddress: user.profile?.roadAddress ?? null,
    city: user.profile?.city ?? null,
    cityCode: user.profile?.cityCode ?? null,
    country: user.profile?.country ?? null,
    countryCode: user.profile?.countryCode ?? null,
    birthdate: user.profile?.birthdate ?? null,
    nationality: user.profile?.nationality ?? null,
    profession: user.profile?.profession ?? null,
    digiformaId: user.profile?.digiformaId ?? null,
    circleId: user.profile?.circleId ?? null,
    practiceName: user.profile?.practiceName ?? null,
    specialties: user.profile?.specialties ?? null,
    certificationLevel: user.profile?.certificationLevel ?? null,
    bio: user.profile?.bio ?? null,
    website: user.profile?.website ?? null,
    profileImageUrl: user.profile?.profileImageUrl ?? null,
    isListed: user.profile?.isListed ?? false,
    latitude: user.profile?.latitude ?? null,
    longitude: user.profile?.longitude ?? null,
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);
  app.use(cookieParser());
  registerAuthRoutes(app);

  app.get("/api/google-maps-key", (_req, res) => {
    const key = process.env.GOOGLE_GEOCODING_API_KEY;
    if (!key) return res.json({ key: null });
    res.json({ key });
  });

  app.get("/healthz", (_req, res) => res.json({ status: "ok" }));

  app.get("/readyz", async (_req, res) => {
    try {
      const { pool } = await import("./storage");
      await pool.query("SELECT 1");
      res.json({ status: "ok", db: "connected" });
    } catch {
      res.status(503).json({ status: "error", db: "unreachable" });
    }
  });

  app.post("/api/webhooks/accredible", async (req, res) => {
    const webhookSecret = req.headers["x-accredible-webhook-secret"] || req.headers["authorization"];
    const expectedSecret = process.env.ACCREDIBLE_WEBHOOK_SECRET;

    if (!expectedSecret || webhookSecret !== expectedSecret) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    try {
      const payload = req.body;
      const credential = payload.credential || payload;

      const data = {
        accredibleCredentialId: String(credential.id || ""),
        recipientEmail: (credential.recipient?.email || credential.email || "").toLowerCase(),
        recipientName: credential.recipient?.name || credential.recipient_name || null,
        groupName: credential.group_name || credential.group?.name || null,
        credentialName: credential.name || credential.group_name || credential.group?.name || "Credential",
        description: credential.description || null,
        issuedAt: credential.issued_on ? new Date(credential.issued_on) : new Date(),
        expiresAt: credential.expired_on ? new Date(credential.expired_on) : null,
        badgeUrl: credential.badge_url || credential.seo_image || null,
        certificateUrl: credential.certificate_url || credential.url || null,
        url: credential.url || null,
      };

      if (!data.recipientEmail) {
        return res.status(400).json({ error: "Missing recipient email" });
      }

      await storage.createAccredibleCredential(data);

      res.json({ success: true });
    } catch (err) {
      console.error("Accredible webhook error:", err);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/me", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });

      await storage.seedCertifications(auth.user.id);

      const passportUser = req.user as any;
      const isImpersonating = !!passportUser?.originalAppUserId;
      return res.json({ user: formatUserResponse(auth.user), isImpersonating });
    } catch (err) {
      console.error("GET /api/me error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/profile", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });

      const parsed = updateProfileSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: parsed.error.errors[0].message });
      }

      if (parsed.data.email && parsed.data.email !== auth.user.email) {
        const existing = await storage.getUserByEmail(parsed.data.email);
        if (existing) {
          return res.status(409).json({ error: "Cette adresse email est déjà utilisée." });
        }
      }

      const addressFields = ["roadAddress", "cityCode", "city", "country"] as const;
      const normalize = (v: string | null | undefined) => (v ?? "").trim();
      const addressChanged = addressFields.some(
        (f) => parsed.data[f] !== undefined && normalize(parsed.data[f]) !== normalize(auth.user.profile?.[f])
      );

      if (addressChanged) {
        if (parsed.data.latitude != null && parsed.data.longitude != null) {
        } else {
          const road = normalize(parsed.data.roadAddress ?? auth.user.profile?.roadAddress);
          const code = normalize(parsed.data.cityCode ?? auth.user.profile?.cityCode);
          const cityVal = normalize(parsed.data.city ?? auth.user.profile?.city);
          const countryVal = normalize(parsed.data.country ?? auth.user.profile?.country);

          const hasAddress = [road, code, cityVal, countryVal].some((v) => v.length > 0);

          if (hasAddress) {
            const coords = await geocodeAddress(null, code || null, cityVal || null, countryVal || null);
            if (coords) {
              parsed.data.latitude = coords.latitude;
              parsed.data.longitude = coords.longitude;
            } else {
              parsed.data.latitude = null;
              parsed.data.longitude = null;
            }
          } else {
            parsed.data.latitude = null;
            parsed.data.longitude = null;
          }
        }
      }

      const updated = await storage.updateUserProfile(auth.user.id, parsed.data);
      
      storage.logActivity({ userId: auth.user.id, action: "profile_update", detail: "Profil mis à jour", ipAddress: req.ip }).catch(() => {});

      return res.json({ user: formatUserResponse(updated) });
    } catch (err) {
      console.error("PATCH /api/profile error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  const uploadsDir = path.join(process.cwd(), "public", "uploads", "avatars");
  fs.mkdirSync(uploadsDir, { recursive: true });

  app.use("/uploads", express.static(path.join(process.cwd(), "public", "uploads")));

  const avatarStorage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (req, file, cb) => {
      const auth = (req as any).auth;
      const ext = path.extname(file.originalname).toLowerCase() || ".jpg";
      cb(null, `${auth?.user?.id || "unknown"}-${Date.now()}${ext}`);
    },
  });

  const avatarUpload = multer({
    storage: avatarStorage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
      const allowed = ["image/jpeg", "image/png", "image/webp"];
      if (allowed.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error("Format non supporté. Utilisez JPG, PNG ou WebP."));
      }
    },
  });

  app.post("/api/profile/avatar", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      (req as any).auth = auth;

      avatarUpload.single("avatar")(req, res, async (err) => {
        if (err) {
          const message = err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE"
            ? "Le fichier est trop volumineux (max 5 Mo)."
            : err.message || "Erreur lors du téléchargement.";
          return res.status(400).json({ error: message });
        }

        if (!req.file) {
          return res.status(400).json({ error: "Aucun fichier fourni." });
        }

        const profileImageUrl = `/uploads/avatars/${req.file.filename}`;
        await storage.updateUserProfile(auth.user.id, { profileImageUrl });
        return res.json({ profileImageUrl });
      });
    } catch (err) {
      console.error("POST /api/profile/avatar error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  const studentRoles: UserRole[] = ["student", "instructor", "admin"];

  app.get("/api/trainings", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      let digiformaId = auth.user.profile?.digiformaId;

      if (!digiformaId) {
        const trainee = await findTraineeByEmail(auth.user.email);
        if (trainee?.id) {
          await storage.updateProfileDigiformaId(auth.user.id, String(trainee.id));
          digiformaId = String(trainee.id);
        }
      }

      if (!digiformaId) {
        return res.json({
          trainings: [],
          linked: false,
          message: "Aucun compte DigiForma trouvé pour cette adresse email.",
        });
      }

      const trainee = await getTraineeWithSessions(digiformaId);
      let allSessions = trainee?.trainingSessions ?? [];

      if (allSessions.length === 0) {
        const allIds = await findAllTraineeIdsByEmail(auth.user.email);
        for (const altId of allIds) {
          if (altId === digiformaId) continue;
          const altTrainee = await getTraineeWithSessions(altId);
          const altSessions = altTrainee?.trainingSessions ?? [];
          if (altSessions.length > 0) {
            allSessions = altSessions;
            await storage.updateProfileDigiformaId(auth.user.id, altId);
            break;
          }
        }
      }

      const registrations = await storage.getTrainingRegistrationsByUserId(auth.user.id);
      const regBySession = new Map(registrations.map(r => [r.sessionId, r]));
      const digiformaSessionIds = new Set(allSessions.map(s => String(s.id)));

      const trainingSessions = allSessions.map((s) => {
        const now = new Date();
        const start = s.startDate ? new Date(s.startDate) : null;
        const end = s.endDate ? new Date(s.endDate) : null;
        let status: "upcoming" | "in_progress" | "completed" = "in_progress";
        if (start && start > now) status = "upcoming";
        else if (end && end < now) status = "completed";
        const reg = regBySession.get(String(s.id));
        return {
          id: s.id,
          name: s.name,
          startDate: s.startDate,
          endDate: s.endDate,
          extranetUrl: s.extranetUrl,
          status,
          place: s.place || null,
          placeName: s.placeName || null,
          remote: s.remote || false,
          program: s.program || null,
          image: s.image || null,
          dates: s.dates || [],
          invoice: reg ? {
            documentNr: reg.bexioDocumentNr,
            total: reg.bexioTotal,
            networkLink: reg.bexioNetworkLink,
            status: reg.status,
          } : null,
        };
      });

      for (const reg of registrations) {
        if (!digiformaSessionIds.has(reg.sessionId)) {
          trainingSessions.push({
            id: reg.sessionId,
            name: reg.programName || 'Formation inscrite',
            startDate: null,
            endDate: null,
            extranetUrl: null,
            status: "upcoming",
            place: null,
            placeName: null,
            remote: false,
            program: null,
            image: null,
            dates: [],
            invoice: {
              documentNr: reg.bexioDocumentNr,
              total: reg.bexioTotal,
              networkLink: reg.bexioNetworkLink,
              status: reg.status,
            },
          });
        }
      }

      return res.json({ trainings: trainingSessions, linked: true });
    } catch (err) {
      console.error("GET /api/trainings error:", err);
      if (err instanceof DigiformaError) {
        return res.status(502).json({
          error: "digiforma_error",
          message: "Impossible de contacter DigiForma. Réessayez plus tard.",
        });
      }
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/certificates", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const certificates = await storage.getCertificationsByUserId(auth.user.id);
      const accredibleCredentials = await storage.getAccredibleCredentialsByUserId(auth.user.id);
      return res.json({ certificates, accredibleCredentials });
    } catch (err) {
      console.error("GET /api/certificates error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/extranet-url", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });

      const extranetUrl = await getExtranetUrl(auth.user.email);
      return res.json({ extranetUrl });
    } catch (err) {
      console.error("GET /api/extranet-url error:", err);
      return res.json({ extranetUrl: null });
    }
  });

  async function getCircleTokenForUser(auth: { user: any }): Promise<CircleAuthToken | null> {
    const circleId = auth.user.profile?.circleId;
    let authToken = circleId
      ? await getCircleMemberToken({ community_member_id: parseInt(circleId, 10) })
      : null;
    if (!authToken) {
      authToken = await getCircleMemberToken({ email: auth.user.email });
    }
    if (!authToken) {
      const displayName = [auth.user.profile?.firstName, auth.user.profile?.lastName]
        .filter(Boolean).join(" ").trim() || auth.user.email;
      const memberId = await createCircleMember(auth.user.email, displayName);
      if (memberId && !auth.user.profile?.circleId) {
        await storage.updateProfileCircleId(auth.user.id, String(memberId));
      }
      authToken = await getCircleMemberToken({ email: auth.user.email });
    }
    if (authToken && auth.user.profile && !auth.user.profile.circleId) {
      await storage.updateProfileCircleId(auth.user.id, String(authToken.community_member_id));
    }
    return authToken;
  }

  app.get("/api/community-link", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const authToken = await getCircleTokenForUser(auth);

      if (!authToken) {
        return res.json({
          communityUrl: getCircleCommunityUrl(),
          redirectUrl: null,
        });
      }

      return res.json({
        communityUrl: getCircleCommunityUrl(),
        redirectUrl: getCircleSsoRedirectUrl(authToken.access_token),
      });
    } catch (err) {
      console.error("GET /api/community-link error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/community/feed", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const authToken = await getCircleTokenForUser(auth);
      if (!authToken) return res.status(502).json({ error: "Could not obtain Circle token" });

      const page = parseInt(String(req.query.page || "1"), 10);
      const perPage = parseInt(String(req.query.per_page || "10"), 10);
      const data = await getCircleHomeFeed(authToken.access_token, page, perPage);
      if (!data) return res.status(502).json({ error: "Failed to fetch feed from Circle" });
      return res.json(data);
    } catch (err) {
      console.error("GET /api/community/feed error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/community/events", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const authToken = await getCircleTokenForUser(auth);
      if (!authToken) return res.status(502).json({ error: "Could not obtain Circle token" });

      const data = await getCircleCommunityEvents(authToken.access_token);
      if (!data) return res.status(502).json({ error: "Failed to fetch events from Circle" });
      return res.json(data);
    } catch (err) {
      console.error("GET /api/community/events error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/community/members", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const authToken = await getCircleTokenForUser(auth);
      if (!authToken) return res.status(502).json({ error: "Could not obtain Circle token" });

      const page = parseInt(String(req.query.page || "1"), 10);
      const perPage = parseInt(String(req.query.per_page || "12"), 10);
      const data = await getCircleCommunityMembers(authToken.access_token, page, perPage);
      if (!data) return res.status(502).json({ error: "Failed to fetch members from Circle" });
      return res.json(data);
    } catch (err) {
      console.error("GET /api/community/members error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/community/spaces", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const authToken = await getCircleTokenForUser(auth);
      if (!authToken) return res.json([]);

      const data = await getCircleSpacesList(authToken.access_token);
      if (!data) return res.json([]);
      return res.json(data);
    } catch (err) {
      console.error("GET /api/community/spaces error:", err);
      return res.json([]);
    }
  });

  app.get("/api/community/sso-token", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const authToken = await getCircleTokenForUser(auth);
      if (!authToken) return res.status(502).json({ error: "Could not obtain Circle token" });

      return res.json({
        access_token: authToken.access_token,
        expires_at: authToken.access_token_expires_at,
        community_member_id: authToken.community_member_id,
      });
    } catch (err) {
      console.error("GET /api/community/sso-token error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/community/me", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const authToken = await getCircleTokenForUser(auth);
      if (!authToken) return res.status(502).json({ error: "Could not obtain Circle token" });

      const data = await getCircleSpaces(authToken.access_token);
      if (!data) return res.status(502).json({ error: "Failed to fetch member info from Circle" });
      return res.json(data);
    } catch (err) {
      console.error("GET /api/community/me error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  let formationsCache: { data: any; timestamp: number } | null = null;
  const FORMATIONS_CACHE_TTL = 5 * 60 * 1000;

  app.get("/api/public/formations", async (_req, res) => {
    try {
      if (formationsCache && Date.now() - formationsCache.timestamp < FORMATIONS_CACHE_TTL) {
        return res.json(formationsCache.data);
      }

      const [programs, sessions, articles] = await Promise.all([
        getAllPrograms(),
        getAllTrainingSessions(),
        fetchArticles(),
      ]);

      const now = new Date();
      const futureSessions = sessions.filter((s) => {
        if (!s.startDate) return false;
        return new Date(s.startDate) > now;
      });

      const programArticleMap = new Map<string, { price: number; articleId: number }>();
      for (const article of articles) {
        if (article.intern_code && article.sale_price) {
          const entry = { price: parseFloat(article.sale_price), articleId: article.id };
          programArticleMap.set(article.intern_code, entry);
          const underscoreIdx = article.intern_code.indexOf('_');
          if (underscoreIdx > 0) {
            const programIdPart = article.intern_code.substring(0, underscoreIdx);
            if (!programArticleMap.has(programIdPart)) {
              programArticleMap.set(programIdPart, entry);
            }
          }
        }
      }

      const programMap = new Map<string, { id: string; name: string }>();
      for (const p of programs) {
        programMap.set(String(p.id), { id: String(p.id), name: p.name });
      }

      const grouped = new Map<string, {
        programs: typeof programs;
        sessions: typeof futureSessions;
      }>();

      for (const session of futureSessions) {
        const programName = session.program?.name || session.name;
        const normalizedName = programName.trim().toLowerCase();
        if (!grouped.has(normalizedName)) {
          grouped.set(normalizedName, { programs: [], sessions: [] });
        }
        grouped.get(normalizedName)!.sessions.push(session);

        if (session.program) {
          const existing = grouped.get(normalizedName)!.programs;
          if (!existing.find((p) => String(p.id) === String(session.program!.id))) {
            const fullProgram = programs.find((p) => String(p.id) === String(session.program!.id));
            if (fullProgram) existing.push(fullProgram);
          }
        }
      }

      for (const program of programs) {
        const normalizedName = program.name.trim().toLowerCase();
        if (!grouped.has(normalizedName)) {
          grouped.set(normalizedName, { programs: [program], sessions: [] });
        } else {
          const existing = grouped.get(normalizedName)!.programs;
          if (!existing.find((p) => String(p.id) === String(program.id))) {
            existing.push(program);
          }
        }
      }

      const result: any[] = [];

      for (const [, group] of grouped) {
        if (group.sessions.length === 0) continue;

        const bestProgram = group.programs.sort((a, b) => {
          const scoreA = (a.image ? 2 : 0) + (a.description ? 1 : 0);
          const scoreB = (b.image ? 2 : 0) + (b.description ? 1 : 0);
          return scoreB - scoreA;
        })[0];

        if (!bestProgram) continue;

        const enrichedSessions = group.sessions
          .sort((a, b) => new Date(a.startDate!).getTime() - new Date(b.startDate!).getTime())
          .map((s) => {
            return {
              id: String(s.id),
              name: s.name,
              code: s.code || '',
              startDate: s.startDate,
              endDate: s.endDate,
              place: s.place,
              placeName: s.placeName,
              remote: s.remote,
              dates: s.dates || [],
            };
          });

        const programBexio = programArticleMap.get(String(bestProgram.id));
        const digiformaCost = bestProgram.costs?.length ? bestProgram.costs[0].cost : null;

        result.push({
          id: String(bestProgram.id),
          name: bestProgram.name,
          description: bestProgram.description ?? null,
          subtitle: bestProgram.subtitle ?? null,
          durationInDays: bestProgram.durationInDays ?? null,
          durationInHours: bestProgram.durationInHours ?? null,
          duration: bestProgram.duration ?? null,
          image: bestProgram.image ? { url: bestProgram.image.url } : null,
          category: bestProgram.category ?? null,
          goals: bestProgram.goals ?? [],
          steps: bestProgram.steps ?? [],
          assessments: bestProgram.assessments ?? [],
          satisfactionRate: bestProgram.satisfactionRate ?? null,
          capacity: bestProgram.capacity ?? null,
          certificationModality: bestProgram.certificationModality ?? null,
          certificationDetails: bestProgram.certificationDetails ?? null,
          admissionModality: bestProgram.admissionModality ?? null,
          trainingModality: bestProgram.trainingModality ?? null,
          handicappedAccessibility: bestProgram.handicappedAccessibility ?? null,
          graduationModality: bestProgram.graduationModality ?? null,
          graduationTarget: bestProgram.graduationTarget ?? null,
          price: programBexio?.price ?? digiformaCost,
          bexioArticleId: programBexio?.articleId ?? null,
          sessions: enrichedSessions,
        });
      }

      result.sort((a, b) => a.name.localeCompare(b.name));

      const responseData = { programs: result };
      formationsCache = { data: responseData, timestamp: Date.now() };

      return res.json(responseData);
    } catch (err) {
      console.error("GET /api/public/formations error:", err);
      if (err instanceof DigiformaError) {
        return res.status(502).json({
          error: "digiforma_error",
          message: "Impossible de charger le catalogue de formations.",
        });
      }
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/register-training", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });

      const { sessionId, programId, sessionDates } = req.body;
      if (!sessionId || typeof sessionId !== 'string' || !programId || typeof programId !== 'string') {
        return res.status(400).json({ error: "sessionId et programId sont requis." });
      }

      let digiformaId = auth.user.profile?.digiformaId;

      if (!digiformaId) {
        try {
          const existingTrainee = await findTraineeByEmail(auth.user.email);
          if (existingTrainee) {
            digiformaId = String(existingTrainee.id);
          } else {
            const newTrainee = await createDigiformaTrainee({
              firstname: auth.user.profile?.firstName || '',
              lastname: auth.user.profile?.lastName || '',
              email: auth.user.email,
            });
            digiformaId = String(newTrainee.id);
          }
          await storage.updateProfileDigiformaId(auth.user.id, digiformaId);
        } catch (err) {
          console.error("DigiForma trainee lookup/creation failed:", err);
          return res.status(502).json({
            error: "digiforma_error",
            message: "Impossible de créer votre profil stagiaire. Réessayez plus tard.",
          });
        }
      }

      try {
        await addDraftTraineeToSession(digiformaId, sessionId);
      } catch (err) {
        console.error("DigiForma session registration failed:", err);
        return res.status(502).json({
          error: "digiforma_error",
          message: "Impossible de vous inscrire à cette session. Réessayez plus tard.",
        });
      }

      let invoice = null;
      let articleName = '';
      try {
        const article = await fetchArticleByInternCode(programId);
        if (article) {
          articleName = article.intern_name;
          const contact = await findOrCreateContact({
            firstName: auth.user.profile?.firstName || '',
            lastName: auth.user.profile?.lastName || '',
            email: auth.user.email,
            phone: auth.user.profile?.phone || undefined,
            address: auth.user.profile?.roadAddress || undefined,
            postcode: auth.user.profile?.cityCode || undefined,
            city: auth.user.profile?.city || undefined,
          });

          const dateComment = typeof sessionDates === 'string' ? sessionDates : '';
          const articleText = dateComment
            ? `${article.intern_name}\nSession : ${dateComment}`
            : article.intern_name;

          invoice = await createAndSendInvoice({
            contactId: contact.id,
            title: `Inscription formation - ${article.intern_name}`,
            articleId: article.id,
            articleName: articleText,
            price: parseFloat(article.sale_price || '0'),
            email: auth.user.email,
            apiReference: `program:${programId}:session:${sessionId}:user:${auth.user.id}`,
          });
        } else {
          console.warn(`No Bexio article found for program ID: ${programId}`);
        }
      } catch (err) {
        console.error("Bexio invoice creation failed (non-blocking):", err);
      }

      await storage.createTrainingRegistration({
        userId: auth.user.id,
        programId,
        programName: articleName || null,
        sessionId,
        sessionDates: typeof sessionDates === 'string' ? sessionDates : null,
        bexioInvoiceId: invoice ? String(invoice.id) : null,
        bexioDocumentNr: invoice?.document_nr || null,
        bexioNetworkLink: invoice?.network_link || null,
        bexioTotal: invoice?.total || null,
        status: 'registered',
      });

      try {
        await sendRegistrationConfirmationEmail(
          auth.user.email,
          auth.user.profile?.firstName || null,
          articleName || 'Formation',
          typeof sessionDates === 'string' ? sessionDates : null,
          invoice?.document_nr || null,
          invoice?.total || null,
          invoice?.network_link || null,
        );
      } catch (emailErr) {
        console.error("Registration confirmation email failed (non-blocking):", emailErr);
      }

      return res.json({
        success: true,
        digiformaRegistered: true,
        invoice: invoice
          ? {
              id: invoice.id,
              documentNr: invoice.document_nr,
              total: invoice.total,
              networkLink: invoice.network_link,
            }
          : null,
      });
    } catch (err) {
      console.error("POST /api/register-training error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/public/calendar", async (_req, res) => {
    try {
      const sessions = await getAllTrainingSessions();
      return res.json({ sessions });
    } catch (err) {
      console.error("GET /api/public/calendar error:", err);
      if (err instanceof DigiformaError) {
        return res.status(502).json({
          error: "digiforma_error",
          message: "Impossible de contacter DigiForma. Réessayez plus tard.",
        });
      }
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/public/directory", async (req, res) => {
    try {
      const params: DirectoryQueryParams = {
        search: req.query.search as string | undefined,
        country: req.query.country as string | undefined,
        specialty: req.query.specialty as string | undefined,
        level: req.query.level as string | undefined,
        page: req.query.page ? parseInt(req.query.page as string) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 24,
      };

      const result = await storage.getDirectoryListings(params);
      const sanitized = result.practitioners.map((p) => {
        if (p.isListed) {
          const { email, phone, roadAddress, ...rest } = p;
          return rest;
        } else {
          return {
            id: p.id,
            slugId: p.slugId,
            digiformaId: p.digiformaId,
            isListed: false,
            firstName: p.firstName,
            lastName: p.lastName ? p.lastName[0] + "." : null,
            city: p.city,
            country: p.country,
            certificationLevel: p.certificationLevel,
            latitude: p.latitude,
            longitude: p.longitude,
            practiceName: null,
            specialties: null,
            bio: null,
            website: null,
            cityCode: p.cityCode,
            profileImageUrl: null,
          };
        }
      });
      return res.json({ practitioners: sanitized, total: result.total });
    } catch (err) {
      console.error("GET /api/public/directory error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/public/directory/filters", async (req, res) => {
    try {
      const { practitioners } = await storage.getDirectoryListings({ limit: 10000 });

      const countries = [...new Set(practitioners.map((p) => p.country).filter(Boolean))] as string[];
      const levels = [...new Set(practitioners.map((p) => p.certificationLevel).filter(Boolean))] as string[];
      const specialties = [...new Set(practitioners.flatMap((p) => p.specialties || []).filter(Boolean))] as string[];

      countries.sort();
      levels.sort();
      specialties.sort();

      return res.json({ countries, levels, specialties });
    } catch (err) {
      console.error("GET /api/public/directory/filters error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/public/directory/:id", async (req, res) => {
    try {
      let entry = await storage.getDirectoryEntryByDigiformaId(req.params.id);
      if (!entry) {
        const numId = parseInt(req.params.id, 10);
        if (!isNaN(numId) && String(numId) === req.params.id) {
          entry = await storage.getDirectoryEntryBySlugId(numId);
        } else {
          entry = await storage.getDirectoryEntry(req.params.id);
        }
      }
      if (!entry) {
        return res.status(404).json({ error: "Praticien non trouvé" });
      }

      if (!entry.isListed) {
        const limited = {
          id: entry.id,
          slugId: entry.slugId,
          digiformaId: entry.digiformaId,
          isListed: false,
          firstName: entry.firstName,
          lastName: entry.lastName ? entry.lastName[0] + "." : null,
          city: entry.city,
          country: entry.country,
          certificationLevel: entry.certificationLevel,
          latitude: entry.latitude,
          longitude: entry.longitude,
          practiceName: null,
          specialties: null,
          bio: null,
          website: null,
          cityCode: entry.cityCode,
          profileImageUrl: null,
        };
        return res.json({ practitioner: limited, certifications: [] });
      }

      const certs = await storage.getCertificationsByUserId(entry.id);
      const { email, phone, roadAddress, ...sanitizedPractitioner } = entry;
      return res.json({ practitioner: sanitizedPractitioner, certifications: certs });
    } catch (err) {
      console.error("GET /api/public/directory/:id error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/directory", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const params: DirectoryQueryParams = {
        search: req.query.search as string | undefined,
        country: req.query.country as string | undefined,
        specialty: req.query.specialty as string | undefined,
        level: req.query.level as string | undefined,
        page: req.query.page ? parseInt(req.query.page as string) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 24,
      };

      const result = await storage.getDirectoryListings(params);
      const sanitized = result.practitioners.map((p) => {
        if (p.isListed) {
          return p;
        } else {
          return {
            id: p.id,
            slugId: p.slugId,
            digiformaId: p.digiformaId,
            isListed: false,
            firstName: p.firstName,
            lastName: p.lastName ? p.lastName[0] + "." : null,
            city: p.city,
            country: p.country,
            certificationLevel: p.certificationLevel,
            latitude: p.latitude,
            longitude: p.longitude,
            practiceName: null,
            specialties: null,
            bio: null,
            website: null,
            email: null,
            phone: null,
            roadAddress: null,
            cityCode: p.cityCode,
            profileImageUrl: null,
          };
        }
      });
      return res.json({ practitioners: sanitized, total: result.total });
    } catch (err) {
      console.error("GET /api/directory error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/directory/filters", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      const { practitioners } = await storage.getDirectoryListings({ limit: 10000 });

      const countries = [...new Set(practitioners.map((p) => p.country).filter(Boolean))] as string[];
      const levels = [...new Set(practitioners.map((p) => p.certificationLevel).filter(Boolean))] as string[];
      const specialties = [...new Set(practitioners.flatMap((p) => p.specialties || []).filter(Boolean))] as string[];

      countries.sort();
      levels.sort();
      specialties.sort();

      return res.json({ countries, levels, specialties });
    } catch (err) {
      console.error("GET /api/directory/filters error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/directory/:id", async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });
      if (!studentRoles.includes(auth.user.role as UserRole)) return res.status(403).json({ error: "Forbidden" });

      let entry = await storage.getDirectoryEntryByDigiformaId(req.params.id);
      if (!entry) {
        const numId = parseInt(req.params.id, 10);
        if (!isNaN(numId) && String(numId) === req.params.id) {
          entry = await storage.getDirectoryEntryBySlugId(numId);
        } else {
          entry = await storage.getDirectoryEntry(req.params.id);
        }
      }
      if (!entry) {
        return res.status(404).json({ error: "Praticien non trouvé" });
      }

      if (!entry.isListed) {
        const limited = {
          id: entry.id,
          slugId: entry.slugId,
          digiformaId: entry.digiformaId,
          isListed: false,
          firstName: entry.firstName,
          lastName: entry.lastName ? entry.lastName[0] + "." : null,
          city: entry.city,
          country: entry.country,
          certificationLevel: entry.certificationLevel,
          latitude: entry.latitude,
          longitude: entry.longitude,
          practiceName: null,
          specialties: null,
          bio: null,
          website: null,
          email: null,
          phone: null,
          roadAddress: null,
          cityCode: entry.cityCode,
          profileImageUrl: null,
        };
        return res.json({ practitioner: limited, certifications: [] });
      }

      const certs = await storage.getCertificationsByUserId(entry.id);
      return res.json({ practitioner: entry, certifications: certs });
    } catch (err) {
      console.error("GET /api/directory/:id error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/admin/sync-trainees", requireRole("admin"), async (req, res) => {
    try {
      const trainees = await getAllTrainees();
      let created = 0;
      let updated = 0;
      let skipped = 0;

      for (const trainee of trainees) {
        if (!trainee.email) {
          skipped++;
          continue;
        }
        const result = await storage.upsertTrainee(
          trainee.email,
          String(trainee.id),
          {
            firstName: trainee.firstname ?? null,
            lastName: trainee.lastname ?? null,
            phone: trainee.phone ?? null,
            phoneSecondary: trainee.phoneSecondary ?? null,
            roadAddress: trainee.roadAddress ?? null,
            city: trainee.city ?? null,
            cityCode: trainee.cityCode ?? null,
            country: trainee.country ?? null,
            countryCode: trainee.countryCode ?? null,
            birthdate: trainee.birthdate ?? null,
            nationality: trainee.nationality ?? null,
            profession: trainee.profession ?? null,
          },
        );
        if (result.created) created++;
        else updated++;
      }

      console.log(`Sync trainees: ${created} created, ${updated} updated, ${skipped} skipped (no email) out of ${trainees.length} total`);
      
      const auth = await authenticateRequest(req);
      if (auth) {
        storage.logActivity({ 
          userId: auth.user.id, 
          action: "sync_trainees", 
          detail: `${created} créés, ${updated} mis à jour, ${skipped} ignorés`,
          ipAddress: req.ip 
        }).catch(() => {});
      }

      return res.json({
        success: true,
        total: trainees.length,
        created,
        updated,
        skipped,
      });
    } catch (err) {
      console.error("POST /api/admin/sync-trainees error:", err);
      if (err instanceof DigiformaError) {
        return res.status(502).json({
          error: "digiforma_error",
          message: "Impossible de contacter DigiForma pour la synchronisation.",
        });
      }
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/admin/geocode-backfill", requireRole("admin"), async (req, res) => {
    try {
      const limit = Math.min(Math.max(parseInt(req.body?.limit as string) || 100, 1), 500);
      const profiles = await storage.getProfilesMissingCoordinates(limit);
      const total = profiles.length;
      let geocoded = 0;
      let failed = 0;
      let processed = 0;

      for (const profile of profiles) {
        processed++;
        try {
          const coords = await geocodeAddress(
            null,
            profile.cityCode,
            profile.city,
            profile.country
          );
          if (coords) {
            await storage.updateProfileCoordinates(profile.userId, coords.latitude, coords.longitude);
            geocoded++;
          } else {
            failed++;
          }
        } catch (err) {
          console.error(`Geocode backfill failed for user ${profile.userId}:`, err);
          failed++;
        }

        if (processed < total) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }

      console.log(`Geocode backfill: ${geocoded} geocoded, ${failed} failed out of ${total} processed`);
      return res.json({
        success: true,
        processed,
        geocoded,
        failed,
        total,
      });
    } catch (err) {
      console.error("POST /api/admin/geocode-backfill error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/admin/sync-circle-events", requireRole("admin"), async (req, res) => {
    try {
      const sessions = await getAllTrainingSessions();
      const now = new Date();
      const futureSessions = sessions.filter(s => {
        if (!s.startDate) return false;
        return new Date(s.startDate) > now;
      });

      const existingEvents = await listCircleEvents();
      const existingNames = new Set(existingEvents.map(e => e.name.trim().toLowerCase()));

      let created = 0;
      let skipped = 0;
      const errors: string[] = [];

      for (const session of futureSessions) {
        const displayName = (session.program?.name || session.name).replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>');

        if (existingNames.has(displayName.trim().toLowerCase())) {
          skipped++;
          continue;
        }

        const startDate = session.startDate!;
        const endDate = session.endDate || startDate;
        let location: string | undefined;
        if (session.placeName) location = session.placeName;
        else if (session.place) location = session.place;
        else if (session.remote) location = "En ligne";

        try {
          await createCircleEvent({
            name: displayName,
            startsAt: new Date(startDate).toISOString(),
            endsAt: new Date(endDate).toISOString(),
            description: `Formation : ${displayName}`,
            location,
          });
          existingNames.add(displayName.trim().toLowerCase());
          created++;
        } catch (err: any) {
          console.error(`Failed to create Circle event "${displayName}":`, err.message);
          errors.push(displayName);
        }
      }

      console.log(`Sync Circle events: ${created} created, ${skipped} skipped (already exist), ${errors.length} errors out of ${futureSessions.length} future sessions`);
      return res.json({
        success: true,
        totalFuture: futureSessions.length,
        created,
        skipped,
        errors: errors.length,
      });
    } catch (err) {
      console.error("POST /api/admin/sync-circle-events error:", err);
      return res.status(500).json({ error: "Internal server error", message: "Impossible de synchroniser les événements Circle." });
    }
  });

  app.post("/api/admin/sync-bexio-articles", requireRole("admin"), async (req, res) => {
    try {
      const [programs, existingArticles] = await Promise.all([
        getAllPrograms(),
        fetchArticles(),
      ]);

      const existingByProgramId = new Map<string, string>();
      for (const a of existingArticles) {
        if (!a.intern_code) continue;
        existingByProgramId.set(a.intern_code, a.intern_code);
        const underscoreIdx = a.intern_code.indexOf('_');
        if (underscoreIdx > 0) {
          existingByProgramId.set(a.intern_code.substring(0, underscoreIdx), a.intern_code);
        }
      }

      const results: { created: string[]; skipped: string[]; errors: string[] } = {
        created: [],
        skipped: [],
        errors: [],
      };

      for (const program of programs) {
        const programId = String(program.id);
        const existingCode = existingByProgramId.get(programId);
        if (existingCode) {
          results.skipped.push(`${existingCode} — ${program.name} (already exists)`);
          continue;
        }

        const programCode = program.code || '';
        const internCode = programCode ? `${programId}_${programCode}` : programId;
        const price = program.costs?.length ? program.costs[0].cost : 0;

        try {
          await createArticle({
            internCode,
            internName: program.name.trim(),
            salePrice: price,
          });
          results.created.push(`${internCode} — ${program.name} (CHF ${price})`);
        } catch (err: any) {
          results.errors.push(`${internCode} — ${program.name}: ${err.message}`);
        }
      }

      return res.json({
        success: true,
        totalPrograms: programs.length,
        ...results,
      });
    } catch (err) {
      console.error("POST /api/admin/sync-bexio-articles error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/admin/users", requireRole("admin"), async (req, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      const formatted = allUsers.map((u) => ({
        id: u.id,
        email: u.email,
        role: u.role,
        firstName: u.profile?.firstName ?? null,
        lastName: u.profile?.lastName ?? null,
        createdAt: u.createdAt,
        emailVerified: u.emailVerified,
        hasPassword: !!u.passwordHash,
        digiformaId: u.profile?.digiformaId ?? null,
        circleId: u.profile?.circleId ?? null,
        isListed: u.profile?.isListed ?? false,
        city: u.profile?.city ?? null,
        country: u.profile?.country ?? null,
        phone: u.profile?.phone ?? null,
        certificationLevel: u.profile?.certificationLevel ?? null,
        profileImageUrl: u.profile?.profileImageUrl ?? null,
      }));
      return res.json({ users: formatted });
    } catch (err) {
      console.error("GET /api/admin/users error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/admin/users/:userId/role", requireRole("admin"), async (req, res) => {
    try {
      const { userId } = req.params;
      const { role } = req.body;
      const validRoles: UserRole[] = ["user", "student", "instructor", "admin"];
      if (!role || !validRoles.includes(role as UserRole)) {
        return res.status(400).json({ error: "Invalid role" });
      }
      const auth = (req as any).auth;
      if (userId === auth.user.id) {
        return res.status(400).json({ error: "Cannot change your own role" });
      }
      await storage.updateUserRole(userId, role);
      await storage.logActivity({
        userId: auth.user.id,
        action: "role_change",
        detail: `Rôle modifié en "${role}" pour l'utilisateur ${userId}`,
        targetType: "user",
        targetId: userId,
        ipAddress: (req.headers["x-forwarded-for"] as string) || req.ip || "",
      });
      return res.json({ success: true });
    } catch (err) {
      console.error("PATCH /api/admin/users/:userId/role error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/admin/stats", requireRole("admin"), async (_req, res) => {
    try {
      const stats = await storage.getUserStats();
      return res.json(stats);
    } catch (err) {
      console.error("GET /api/admin/stats error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/admin/activity", requireRole("admin"), async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
      const logs = await storage.getRecentActivityLogs(limit);
      return res.json({ logs });
    } catch (err) {
      console.error("GET /api/admin/activity error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/admin/impersonate/:userId", requireRole("admin"), async (req, res) => {
    try {
      const auth = await authenticateRequest(req);
      if (!auth) return res.status(401).json({ error: "Unauthorized" });

      if (req.params.userId === auth.user.id) {
        return res.status(400).json({ error: "Impossible de se connecter en tant que soi-même" });
      }

      const targetUser = await storage.getUserById(req.params.userId);
      if (!targetUser) {
        return res.status(404).json({ error: "Utilisateur non trouvé" });
      }

      if (targetUser.role === "admin") {
        return res.status(403).json({ error: "Impossible de se connecter en tant qu'administrateur" });
      }

      const passportUser = req.user as any;
      passportUser.originalAppUserId = passportUser.appUserId;
      passportUser.appUserId = targetUser.id;

      storage.logActivity({
        userId: auth.user.id,
        action: "impersonate",
        detail: `Connexion en tant que ${targetUser.email}`,
        targetType: "user",
        targetId: targetUser.id,
        ipAddress: req.ip
      }).catch(() => {});

      return res.json({ success: true, user: formatUserResponse(targetUser) });
    } catch (err) {
      console.error("POST /api/admin/impersonate error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/admin/stop-impersonate", async (req, res) => {
    try {
      const passportUser = req.user as any;
      if (!passportUser?.originalAppUserId) {
        return res.status(400).json({ error: "Aucune session d'impersonation active" });
      }

      passportUser.appUserId = passportUser.originalAppUserId;
      delete passportUser.originalAppUserId;

      const adminUser = await storage.getUserById(passportUser.appUserId);
      if (!adminUser) {
        return res.status(401).json({ error: "Session admin expirée" });
      }

      return res.json({ success: true, user: formatUserResponse(adminUser) });
    } catch (err) {
      console.error("POST /api/admin/stop-impersonate error:", err);
      return res.status(500).json({ error: "Internal server error" });
    }
  });

  return httpServer;
}
