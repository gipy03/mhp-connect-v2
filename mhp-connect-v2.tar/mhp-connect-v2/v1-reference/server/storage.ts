import {
  type User,
  type UserProfile,
  type Certification,
  type AuthToken,
  type InsertCertification,
  type UpdateProfile,
  type InsertTrainingRegistration,
  type TrainingRegistration,
  type ActivityLog,
  type InsertActivityLog,
  type AccredibleCredential,
  type InsertAccredibleCredential,
  users,
  userProfiles,
  certifications,
  authTokens,
  trainingRegistrations,
  activityLogs,
  accredibleCredentials,
} from "@shared/schema";
import { eq, and, gt, sql, or, ilike, isNotNull, isNull, count } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import bcrypt from "bcryptjs";
import crypto from "crypto";

export interface TraineePersonalData {
  firstName?: string | null;
  lastName?: string | null;
  phone?: string | null;
  phoneSecondary?: string | null;
  roadAddress?: string | null;
  city?: string | null;
  cityCode?: string | null;
  country?: string | null;
  countryCode?: string | null;
  birthdate?: string | null;
  nationality?: string | null;
  profession?: string | null;
}

export type UserWithProfile = User & {
  profile: UserProfile | null;
};

export interface IStorage {
  getUserByEmail(email: string): Promise<UserWithProfile | undefined>;
  getUserById(id: string): Promise<UserWithProfile | undefined>;
  createUser(email: string, passwordHash: string, firstName: string, lastName: string, role?: string): Promise<UserWithProfile>;
  updateUserProfile(userId: string, data: UpdateProfile): Promise<UserWithProfile>;
  updateUserEmail(userId: string, email: string): Promise<void>;
  updateUserPassword(userId: string, passwordHash: string): Promise<void>;
  updateUserRole(userId: string, role: string): Promise<void>;
  updateProfileDigiformaId(userId: string, digiformaId: string): Promise<void>;
  updateProfileCircleId(userId: string, circleId: string): Promise<void>;
  getCertificationsByUserId(userId: string): Promise<Certification[]>;
  createCertification(cert: InsertCertification): Promise<Certification>;
  seedCertifications(userId: string): Promise<void>;
  upsertTrainee(email: string, digiformaId: string, personalData: TraineePersonalData): Promise<{ created: boolean }>;
  completePreImportedUser(userId: string, passwordHash: string, firstName: string, lastName: string): Promise<UserWithProfile>;
  createAuthToken(userId: string, type: string, expiresInMs: number): Promise<string>;
  getValidAuthToken(token: string, type: string): Promise<(AuthToken & { user: User }) | null>;
  markTokenUsed(tokenId: string): Promise<void>;
  invalidateUserTokens(userId: string, type: string): Promise<void>;
  getAllUsers(): Promise<UserWithProfile[]>;
  getDirectoryListings(params: DirectoryQueryParams): Promise<{ practitioners: DirectoryEntry[]; total: number }>;
  getDirectoryEntry(userId: string): Promise<DirectoryEntry | null>;
  getDirectoryEntryBySlugId(slugId: number): Promise<DirectoryEntry | null>;
  getDirectoryEntryByDigiformaId(digiformaId: string): Promise<DirectoryEntry | null>;
  createTrainingRegistration(data: InsertTrainingRegistration): Promise<TrainingRegistration>;
  getTrainingRegistrationsByUserId(userId: string): Promise<TrainingRegistration[]>;
  getProfilesMissingCoordinates(limit: number): Promise<{ userId: string; roadAddress: string | null; city: string | null; cityCode: string | null; country: string | null }[]>;
  updateProfileCoordinates(userId: string, latitude: number | null, longitude: number | null): Promise<void>;
  logActivity(data: InsertActivityLog): Promise<ActivityLog>;
  getRecentActivityLogs(limit?: number): Promise<(ActivityLog & { userName?: string; userEmail?: string })[]>;
  getUserStats(): Promise<{ total: number; students: number; admins: number; withPassword: number; listed: number }>;
  createAccredibleCredential(data: InsertAccredibleCredential): Promise<AccredibleCredential>;
  getAccredibleCredentialsByEmail(email: string): Promise<AccredibleCredential[]>;
  getAccredibleCredentialsByUserId(userId: string): Promise<AccredibleCredential[]>;
  linkAccredibleCredentialsToUser(email: string, userId: string): Promise<void>;
}

export interface DirectoryQueryParams {
  search?: string;
  country?: string;
  specialty?: string;
  level?: string;
  page?: number;
  limit?: number;
}

export interface DirectoryEntry {
  id: string;
  slugId: number;
  digiformaId: string | null;
  isListed: boolean | null;
  firstName: string | null;
  lastName: string | null;
  city: string | null;
  country: string | null;
  practiceName: string | null;
  specialties: string[] | null;
  certificationLevel: string | null;
  bio: string | null;
  website: string | null;
  phone: string | null;
  email: string;
  roadAddress: string | null;
  cityCode: string | null;
  latitude: number | null;
  longitude: number | null;
  profileImageUrl: string | null;
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(pool);

export class DatabaseStorage implements IStorage {
  private async getUserWithProfile(user: User): Promise<UserWithProfile> {
    const [profile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, user.id));
    return { ...user, profile: profile || null };
  }

  async getUserByEmail(email: string): Promise<UserWithProfile | undefined> {
    const normalized = email.toLowerCase().trim();
    const [row] = await db.select().from(users).where(sql`lower(${users.email}) = ${normalized}`);
    if (!row) return undefined;
    return this.getUserWithProfile(row);
  }

  async getUserById(id: string): Promise<UserWithProfile | undefined> {
    const [row] = await db.select().from(users).where(eq(users.id, id));
    if (!row) return undefined;
    return this.getUserWithProfile(row);
  }

  async createUser(email: string, passwordHash: string, firstName: string, lastName: string, role: string = "user"): Promise<UserWithProfile> {
    const [user] = await db
      .insert(users)
      .values({ email: email.toLowerCase().trim(), passwordHash, role, emailVerified: true })
      .returning();
    const [profile] = await db
      .insert(userProfiles)
      .values({ userId: user.id, firstName, lastName })
      .returning();
    return { ...user, profile };
  }

  async updateUserProfile(userId: string, data: UpdateProfile): Promise<UserWithProfile> {
    if (data.email) {
      await db.update(users).set({ email: data.email, updatedAt: new Date() }).where(eq(users.id, userId));
    }

    const profileFields: Record<string, any> = { updatedAt: new Date() };
    const allowedProfileFields = [
      'firstName', 'lastName',
      'phone', 'phoneSecondary', 'roadAddress',
      'city', 'cityCode', 'country', 'countryCode',
      'birthdate', 'nationality', 'profession',
      'practiceName', 'specialties', 'certificationLevel',
      'bio', 'website', 'profileImageUrl', 'isListed', 'latitude', 'longitude',
    ];
    const d = data as Record<string, any>;
    for (const field of allowedProfileFields) {
      if (d[field] !== undefined) profileFields[field] = d[field];
    }

    const [existing] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    if (existing) {
      await db.update(userProfiles).set(profileFields).where(eq(userProfiles.userId, userId));
    } else {
      await db.insert(userProfiles).values({ userId, ...profileFields });
    }

    return (await this.getUserById(userId))!;
  }

  async updateUserEmail(userId: string, email: string): Promise<void> {
    await db.update(users).set({ email, updatedAt: new Date() }).where(eq(users.id, userId));
  }

  async updateUserPassword(userId: string, passwordHash: string): Promise<void> {
    await db.update(users).set({ passwordHash, emailVerified: true, updatedAt: new Date() }).where(eq(users.id, userId));
  }

  async updateUserRole(userId: string, role: string): Promise<void> {
    await db.update(users).set({ role, updatedAt: new Date() }).where(eq(users.id, userId));
  }

  async updateProfileDigiformaId(userId: string, digiformaId: string): Promise<void> {
    const [existing] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    if (existing) {
      await db.update(userProfiles).set({ digiformaId }).where(eq(userProfiles.userId, userId));
    } else {
      await db.insert(userProfiles).values({ userId, digiformaId });
    }
  }

  async updateProfileCircleId(userId: string, circleId: string): Promise<void> {
    const [existing] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    if (existing) {
      await db.update(userProfiles).set({ circleId }).where(eq(userProfiles.userId, userId));
    } else {
      await db.insert(userProfiles).values({ userId, circleId });
    }
  }

  async getCertificationsByUserId(userId: string): Promise<Certification[]> {
    return db.select().from(certifications).where(eq(certifications.userId, userId));
  }

  async createCertification(cert: InsertCertification): Promise<Certification> {
    const [created] = await db.insert(certifications).values(cert).returning();
    return created;
  }

  async upsertTrainee(email: string, digiformaId: string, personalData: TraineePersonalData): Promise<{ created: boolean }> {
    const normalizedEmail = email.toLowerCase().trim();
    const existing = await this.getUserByEmail(normalizedEmail);

    const profileFields: Record<string, any> = {
      digiformaId,
      phone: personalData.phone ?? null,
      phoneSecondary: personalData.phoneSecondary ?? null,
      roadAddress: personalData.roadAddress ?? null,
      city: personalData.city ?? null,
      cityCode: personalData.cityCode ?? null,
      country: personalData.country ?? null,
      countryCode: personalData.countryCode ?? null,
      birthdate: personalData.birthdate ?? null,
      nationality: personalData.nationality ?? null,
      profession: personalData.profession ?? null,
    };

    if (existing) {
      const profileUpdates: Record<string, any> = { ...profileFields, updatedAt: new Date() };
      if (!existing.passwordHash) {
        if (personalData.firstName) profileUpdates.firstName = personalData.firstName;
        if (personalData.lastName) profileUpdates.lastName = personalData.lastName;
      }

      const [existingProfile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, existing.id));
      if (existingProfile) {
        await db.update(userProfiles).set(profileUpdates).where(eq(userProfiles.userId, existing.id));
      } else {
        await db.insert(userProfiles).values({
          userId: existing.id,
          firstName: personalData.firstName ?? null,
          lastName: personalData.lastName ?? null,
          ...profileFields,
        });
      }

      if (existing.role === "user") {
        await db.update(users).set({ role: "student", updatedAt: new Date() }).where(eq(users.id, existing.id));
      }

      return { created: false };
    }

    const [newUser] = await db.insert(users).values({
      email: normalizedEmail,
      role: "student",
    }).returning();

    await db.insert(userProfiles).values({
      userId: newUser.id,
      firstName: personalData.firstName ?? null,
      lastName: personalData.lastName ?? null,
      ...profileFields,
    });

    return { created: true };
  }

  async completePreImportedUser(userId: string, passwordHash: string, firstName: string, lastName: string): Promise<UserWithProfile> {
    await db.update(users).set({
      passwordHash,
      emailVerified: true,
      updatedAt: new Date(),
    }).where(eq(users.id, userId));

    const [existingProfile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    if (existingProfile) {
      await db.update(userProfiles).set({ firstName, lastName, updatedAt: new Date() }).where(eq(userProfiles.userId, userId));
    } else {
      await db.insert(userProfiles).values({ userId, firstName, lastName });
    }

    return (await this.getUserById(userId))!;
  }

  async createAuthToken(userId: string, type: string, expiresInMs: number): Promise<string> {
    await db.delete(authTokens).where(and(eq(authTokens.userId, userId), eq(authTokens.type, type)));

    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + expiresInMs);

    await db.insert(authTokens).values({ userId, token, type, expiresAt });
    return token;
  }

  async getValidAuthToken(token: string, type: string): Promise<(AuthToken & { user: User }) | null> {
    const rows = await db
      .select()
      .from(authTokens)
      .innerJoin(users, eq(authTokens.userId, users.id))
      .where(
        and(
          eq(authTokens.token, token),
          eq(authTokens.type, type),
          gt(authTokens.expiresAt, new Date()),
        )
      );

    if (rows.length === 0) return null;
    const row = rows[0];
    if (row.auth_tokens.usedAt) return null;
    return { ...row.auth_tokens, user: row.users };
  }

  async markTokenUsed(tokenId: string): Promise<void> {
    await db.update(authTokens).set({ usedAt: new Date() }).where(eq(authTokens.id, tokenId));
  }

  async invalidateUserTokens(userId: string, type: string): Promise<void> {
    await db.delete(authTokens).where(and(eq(authTokens.userId, userId), eq(authTokens.type, type)));
  }

  async getAllUsers(): Promise<UserWithProfile[]> {
    const allUsers = await db.select().from(users);
    const result: UserWithProfile[] = [];
    for (const user of allUsers) {
      result.push(await this.getUserWithProfile(user));
    }
    return result;
  }

  async getDirectoryListings(params: DirectoryQueryParams): Promise<{ practitioners: DirectoryEntry[]; total: number }> {
    const { search, country, specialty, level, page = 1, limit = 24 } = params;
    const offset = (page - 1) * limit;

    const conditions: any[] = [isNotNull(userProfiles.firstName)];

    if (search) {
      const term = `%${search}%`;
      conditions.push(
        or(
          ilike(userProfiles.firstName, term),
          ilike(userProfiles.lastName, term),
          ilike(userProfiles.city, term),
          ilike(userProfiles.practiceName, term),
        )
      );
    }

    if (country) {
      conditions.push(ilike(userProfiles.country, country));
    }

    if (level) {
      conditions.push(ilike(userProfiles.certificationLevel, level));
    }

    if (specialty) {
      conditions.push(sql`${specialty} = ANY(${userProfiles.specialties})`);
    }

    const whereClause = and(...conditions);

    const countResult = await db
      .select({ total: count() })
      .from(userProfiles)
      .innerJoin(users, eq(userProfiles.userId, users.id))
      .where(whereClause);

    const total = Number(countResult[0]?.total ?? 0);

    const rows = await db
      .select({
        id: users.id,
        slugId: userProfiles.slugId,
        digiformaId: userProfiles.digiformaId,
        isListed: userProfiles.isListed,
        email: users.email,
        firstName: userProfiles.firstName,
        lastName: userProfiles.lastName,
        city: userProfiles.city,
        country: userProfiles.country,
        practiceName: userProfiles.practiceName,
        specialties: userProfiles.specialties,
        certificationLevel: userProfiles.certificationLevel,
        bio: userProfiles.bio,
        website: userProfiles.website,
        phone: userProfiles.phone,
        roadAddress: userProfiles.roadAddress,
        cityCode: userProfiles.cityCode,
        latitude: userProfiles.latitude,
        longitude: userProfiles.longitude,
        profileImageUrl: userProfiles.profileImageUrl,
      })
      .from(userProfiles)
      .innerJoin(users, eq(userProfiles.userId, users.id))
      .where(whereClause)
      .limit(limit)
      .offset(offset);

    return { practitioners: rows as DirectoryEntry[], total };
  }

  async getDirectoryEntry(userId: string): Promise<DirectoryEntry | null> {
    const rows = await db
      .select({
        id: users.id,
        slugId: userProfiles.slugId,
        digiformaId: userProfiles.digiformaId,
        isListed: userProfiles.isListed,
        email: users.email,
        firstName: userProfiles.firstName,
        lastName: userProfiles.lastName,
        city: userProfiles.city,
        country: userProfiles.country,
        practiceName: userProfiles.practiceName,
        specialties: userProfiles.specialties,
        certificationLevel: userProfiles.certificationLevel,
        bio: userProfiles.bio,
        website: userProfiles.website,
        phone: userProfiles.phone,
        roadAddress: userProfiles.roadAddress,
        cityCode: userProfiles.cityCode,
        latitude: userProfiles.latitude,
        longitude: userProfiles.longitude,
        profileImageUrl: userProfiles.profileImageUrl,
      })
      .from(userProfiles)
      .innerJoin(users, eq(userProfiles.userId, users.id))
      .where(eq(users.id, userId));

    if (rows.length === 0) return null;
    return rows[0] as DirectoryEntry;
  }

  async getDirectoryEntryBySlugId(slugId: number): Promise<DirectoryEntry | null> {
    const rows = await db
      .select({
        id: users.id,
        slugId: userProfiles.slugId,
        digiformaId: userProfiles.digiformaId,
        isListed: userProfiles.isListed,
        email: users.email,
        firstName: userProfiles.firstName,
        lastName: userProfiles.lastName,
        city: userProfiles.city,
        country: userProfiles.country,
        practiceName: userProfiles.practiceName,
        specialties: userProfiles.specialties,
        certificationLevel: userProfiles.certificationLevel,
        bio: userProfiles.bio,
        website: userProfiles.website,
        phone: userProfiles.phone,
        roadAddress: userProfiles.roadAddress,
        cityCode: userProfiles.cityCode,
        latitude: userProfiles.latitude,
        longitude: userProfiles.longitude,
        profileImageUrl: userProfiles.profileImageUrl,
      })
      .from(userProfiles)
      .innerJoin(users, eq(userProfiles.userId, users.id))
      .where(eq(userProfiles.slugId, slugId));

    if (rows.length === 0) return null;
    return rows[0] as DirectoryEntry;
  }

  async getDirectoryEntryByDigiformaId(digiformaId: string): Promise<DirectoryEntry | null> {
    const rows = await db
      .select({
        id: users.id,
        slugId: userProfiles.slugId,
        digiformaId: userProfiles.digiformaId,
        isListed: userProfiles.isListed,
        email: users.email,
        firstName: userProfiles.firstName,
        lastName: userProfiles.lastName,
        city: userProfiles.city,
        country: userProfiles.country,
        practiceName: userProfiles.practiceName,
        specialties: userProfiles.specialties,
        certificationLevel: userProfiles.certificationLevel,
        bio: userProfiles.bio,
        website: userProfiles.website,
        phone: userProfiles.phone,
        roadAddress: userProfiles.roadAddress,
        cityCode: userProfiles.cityCode,
        latitude: userProfiles.latitude,
        longitude: userProfiles.longitude,
        profileImageUrl: userProfiles.profileImageUrl,
      })
      .from(userProfiles)
      .innerJoin(users, eq(userProfiles.userId, users.id))
      .where(eq(userProfiles.digiformaId, digiformaId));

    if (rows.length === 0) return null;
    return rows[0] as DirectoryEntry;
  }

  async createTrainingRegistration(data: InsertTrainingRegistration): Promise<TrainingRegistration> {
    const [reg] = await db
      .insert(trainingRegistrations)
      .values(data)
      .returning();
    return reg;
  }

  async getTrainingRegistrationsByUserId(userId: string): Promise<TrainingRegistration[]> {
    return db
      .select()
      .from(trainingRegistrations)
      .where(eq(trainingRegistrations.userId, userId))
      .orderBy(sql`created_at DESC`);
  }

  async getProfilesMissingCoordinates(limit: number): Promise<{ userId: string; roadAddress: string | null; city: string | null; cityCode: string | null; country: string | null }[]> {
    const rows = await db
      .select({
        userId: userProfiles.userId,
        roadAddress: userProfiles.roadAddress,
        city: userProfiles.city,
        cityCode: userProfiles.cityCode,
        country: userProfiles.country,
      })
      .from(userProfiles)
      .where(
        and(
          or(isNotNull(userProfiles.roadAddress), isNotNull(userProfiles.city)),
          isNull(userProfiles.latitude)
        )
      )
      .limit(limit);
    return rows;
  }

  async updateProfileCoordinates(userId: string, latitude: number | null, longitude: number | null): Promise<void> {
    await db.update(userProfiles).set({ latitude, longitude, updatedAt: new Date() }).where(eq(userProfiles.userId, userId));
  }

  async seedCertifications(userId: string): Promise<void> {
    const existing = await this.getCertificationsByUserId(userId);
    if (existing.length > 0) return;

    const samples: InsertCertification[] = [
      {
        userId,
        certificationName: "Praticien en Hypnose",
        issuingBody: "MHP Formation",
        issuedAt: "2024-06-15",
        expiresAt: null,
        status: "active",
        verificationUrl: null,
        certificateImageUrl: null,
      },
      {
        userId,
        certificationName: "Technicien PNL",
        issuingBody: "MHP Formation",
        issuedAt: "2024-03-10",
        expiresAt: "2027-03-10",
        status: "active",
        verificationUrl: null,
        certificateImageUrl: null,
      },
    ];

    for (const sample of samples) {
      await db.insert(certifications).values(sample);
    }
  }
  async logActivity(data: InsertActivityLog): Promise<ActivityLog> {
    const [log] = await db.insert(activityLogs).values(data).returning();
    return log;
  }

  async getRecentActivityLogs(limit = 50): Promise<(ActivityLog & { userName?: string; userEmail?: string })[]> {
    const rows = await db
      .select({
        id: activityLogs.id,
        userId: activityLogs.userId,
        action: activityLogs.action,
        detail: activityLogs.detail,
        targetType: activityLogs.targetType,
        targetId: activityLogs.targetId,
        ipAddress: activityLogs.ipAddress,
        createdAt: activityLogs.createdAt,
        firstName: userProfiles.firstName,
        lastName: userProfiles.lastName,
        email: users.email,
      })
      .from(activityLogs)
      .leftJoin(users, eq(activityLogs.userId, users.id))
      .leftJoin(userProfiles, eq(activityLogs.userId, userProfiles.userId))
      .orderBy(sql`${activityLogs.createdAt} DESC`)
      .limit(limit);

    return rows.map((r) => ({
      id: r.id,
      userId: r.userId,
      action: r.action,
      detail: r.detail,
      targetType: r.targetType,
      targetId: r.targetId,
      ipAddress: r.ipAddress,
      createdAt: r.createdAt,
      userName: [r.firstName, r.lastName].filter(Boolean).join(" ") || undefined,
      userEmail: r.email ?? undefined,
    }));
  }

  async getUserStats(): Promise<{ total: number; students: number; admins: number; withPassword: number; listed: number }> {
    const [totalRow] = await db.select({ count: count() }).from(users);
    const [studentsRow] = await db.select({ count: count() }).from(users).where(eq(users.role, "student"));
    const [adminsRow] = await db.select({ count: count() }).from(users).where(eq(users.role, "admin"));
    const [withPwRow] = await db.select({ count: count() }).from(users).where(isNotNull(users.passwordHash));
    const [listedRow] = await db.select({ count: count() }).from(userProfiles).where(eq(userProfiles.isListed, true));
    return {
      total: totalRow.count,
      students: studentsRow.count,
      admins: adminsRow.count,
      withPassword: withPwRow.count,
      listed: listedRow.count,
    };
  }

  async createAccredibleCredential(data: InsertAccredibleCredential): Promise<AccredibleCredential> {
    const email = data.recipientEmail.toLowerCase().trim();
    if (!email) throw new Error("recipientEmail is required");
    const user = await this.getUserByEmail(email);
    const values = { ...data, recipientEmail: email, userId: user?.id ?? null };

    if (data.accredibleCredentialId) {
      const [upserted] = await db
        .insert(accredibleCredentials)
        .values(values)
        .onConflictDoUpdate({
          target: accredibleCredentials.accredibleCredentialId,
          set: {
            recipientName: values.recipientName,
            groupName: values.groupName,
            credentialName: values.credentialName,
            description: values.description,
            issuedAt: values.issuedAt,
            expiresAt: values.expiresAt,
            badgeUrl: values.badgeUrl,
            certificateUrl: values.certificateUrl,
            url: values.url,
            userId: values.userId,
          },
        })
        .returning();
      return upserted;
    }

    const [created] = await db
      .insert(accredibleCredentials)
      .values(values)
      .returning();
    return created;
  }

  async getAccredibleCredentialsByEmail(email: string): Promise<AccredibleCredential[]> {
    return db
      .select()
      .from(accredibleCredentials)
      .where(eq(accredibleCredentials.recipientEmail, email.toLowerCase().trim()))
      .orderBy(sql`${accredibleCredentials.issuedAt} DESC`);
  }

  async getAccredibleCredentialsByUserId(userId: string): Promise<AccredibleCredential[]> {
    return db
      .select()
      .from(accredibleCredentials)
      .where(eq(accredibleCredentials.userId, userId))
      .orderBy(sql`${accredibleCredentials.issuedAt} DESC`);
  }

  async linkAccredibleCredentialsToUser(email: string, userId: string): Promise<void> {
    await db
      .update(accredibleCredentials)
      .set({ userId })
      .where(eq(accredibleCredentials.recipientEmail, email.toLowerCase().trim()));
  }
}

export const storage = new DatabaseStorage();
