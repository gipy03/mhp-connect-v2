const CIRCLE_API_BASE = 'https://app.circle.so';
const AGENDA_SPACE_ID = 1017854;

function getAdminHeaders(): Record<string, string> {
  const token = process.env.CIRCLE_API_TOKEN;
  if (!token) throw new Error('CIRCLE_API_TOKEN is not configured');
  return {
    'Authorization': `Token ${token}`,
    'Content-Type': 'application/json',
  };
}

export interface CircleAuthToken {
  access_token: string;
  access_token_expires_at: string;
  refresh_token: string;
  refresh_token_expires_at: string;
  community_member_id: number;
  community_id: number;
}

export async function getCircleMemberToken(identifier: { email?: string; community_member_id?: number }): Promise<CircleAuthToken | null> {
  const token = process.env.CIRCLE_HEADLESS_API || process.env.CIRCLE_API_TOKEN;
  if (!token) return null;
  try {
    const body: Record<string, any> = {};
    if (identifier.community_member_id) {
      body.community_member_id = identifier.community_member_id;
    } else if (identifier.email) {
      body.email = identifier.email;
    } else {
      return null;
    }
    const res = await fetch('https://app.circle.so/api/v1/headless/auth_token', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const text = await res.text();
      console.error(`Circle headless auth error: ${res.status} ${text}`);
      return null;
    }
    const data = await res.json();
    if (!data.access_token) {
      console.error('Circle headless auth: no access_token in response', JSON.stringify(data));
      return null;
    }
    return data as CircleAuthToken;
  } catch (err) {
    console.error('Circle headless auth exception:', err);
    return null;
  }
}

export async function createCircleMember(email: string, name: string): Promise<number | null> {
  try {
    const res = await fetch(`${CIRCLE_API_BASE}/api/admin/v2/community_members`, {
      method: 'POST',
      headers: getAdminHeaders(),
      body: JSON.stringify({
        email,
        name,
        skip_invitation: true,
      }),
    });
    if (!res.ok) {
      const text = await res.text();
      console.error(`Circle API error creating member: ${res.status} ${text}`);
      return null;
    }
    const data = await res.json();
    return data.id ?? null;
  } catch (err) {
    console.error("Circle createMember error:", err);
    return null;
  }
}

export function getCircleCommunityUrl(): string {
  let url = process.env.CIRCLE_COMMUNITY_URL || 'https://community.mhp-hypnose.com';
  url = url.trim().replace(/^\/+/, '');
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = `https://${url}`;
  }
  return url.replace(/\/+$/, '');
}

export function getCircleSsoRedirectUrl(accessToken: string): string {
  const communityUrl = getCircleCommunityUrl();
  return `${communityUrl}/session/cookies?access_token=${encodeURIComponent(accessToken)}`;
}

export interface CircleEvent {
  id: number;
  name: string;
  slug: string;
  starts_at: string | null;
  ends_at: string | null;
  url: string;
  space: { id: number; name: string };
}

export async function listCircleEvents(spaceId: number = AGENDA_SPACE_ID): Promise<CircleEvent[]> {
  const allEvents: CircleEvent[] = [];
  let page = 1;
  const perPage = 50;

  while (true) {
    const res = await fetch(
      `${CIRCLE_API_BASE}/api/admin/v2/events?space_id=${spaceId}&per_page=${perPage}&page=${page}`,
      { headers: getAdminHeaders() }
    );
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Circle API error listing events: ${res.status} ${text}`);
    }
    const data = await res.json();
    const records = data.records ?? [];
    allEvents.push(...records);
    if (!data.has_next_page) break;
    page++;
  }

  return allEvents;
}

export interface CreateCircleEventParams {
  name: string;
  startsAt: string;
  endsAt: string;
  description?: string;
  location?: string;
  spaceId?: number;
}

function getMemberHeaders(accessToken: string): Record<string, string> {
  return {
    'Authorization': `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };
}

export async function getCircleHomeFeed(accessToken: string, page = 1, perPage = 10): Promise<any | null> {
  try {
    const res = await fetch(
      `${CIRCLE_API_BASE}/api/headless/v1/home?page=${page}&per_page=${perPage}&sort=latest`,
      { headers: getMemberHeaders(accessToken) }
    );
    if (!res.ok) {
      console.error(`Circle home feed error: ${res.status} ${await res.text()}`);
      return null;
    }
    return await res.json();
  } catch (err) {
    console.error('Circle home feed exception:', err);
    return null;
  }
}

export async function getCircleCommunityEvents(accessToken: string): Promise<any | null> {
  try {
    const res = await fetch(
      `${CIRCLE_API_BASE}/api/headless/v1/community_events?status=upcoming&per_page=10&sort=starts_at`,
      { headers: getMemberHeaders(accessToken) }
    );
    if (!res.ok) {
      console.error(`Circle community events error: ${res.status} ${await res.text()}`);
      return null;
    }
    return await res.json();
  } catch (err) {
    console.error('Circle community events exception:', err);
    return null;
  }
}

export async function getCircleCommunityMembers(accessToken: string, page = 1, perPage = 12): Promise<any | null> {
  try {
    const res = await fetch(
      `${CIRCLE_API_BASE}/api/headless/v1/community_members?page=${page}&per_page=${perPage}`,
      { headers: getMemberHeaders(accessToken) }
    );
    if (!res.ok) {
      console.error(`Circle community members error: ${res.status} ${await res.text()}`);
      return null;
    }
    return await res.json();
  } catch (err) {
    console.error('Circle community members exception:', err);
    return null;
  }
}

export async function getCircleSpaces(accessToken: string): Promise<any | null> {
  try {
    const res = await fetch(
      `${CIRCLE_API_BASE}/api/headless/v1/community_member`,
      { headers: getMemberHeaders(accessToken) }
    );
    if (!res.ok) {
      console.error(`Circle spaces error: ${res.status} ${await res.text()}`);
      return null;
    }
    return await res.json();
  } catch (err) {
    console.error('Circle spaces exception:', err);
    return null;
  }
}

export async function getCircleSpacesList(accessToken: string): Promise<any | null> {
  try {
    const res = await fetch(
      `${CIRCLE_API_BASE}/api/headless/v1/spaces`,
      { headers: getMemberHeaders(accessToken) }
    );
    if (!res.ok) {
      console.error(`Circle spaces list error: ${res.status} ${await res.text()}`);
      return null;
    }
    return await res.json();
  } catch (err) {
    console.error('Circle spaces list exception:', err);
    return null;
  }
}

export async function createCircleEvent(params: CreateCircleEventParams): Promise<CircleEvent> {
  const spaceId = params.spaceId ?? AGENDA_SPACE_ID;

  const bodyContent: any[] = [];
  if (params.description) {
    bodyContent.push({
      type: "paragraph",
      content: [{ type: "text", text: params.description }]
    });
  }
  if (params.location) {
    bodyContent.push({
      type: "paragraph",
      content: [{ type: "text", text: `📍 ${params.location}` }]
    });
  }

  const isVirtual = !params.location || params.location === "En ligne";

  const eventPayload: any = {
    space_id: spaceId,
    name: params.name,
    status: "published",
    event_setting_attributes: {
      starts_at: params.startsAt,
      ends_at: params.endsAt,
      duration_in_seconds: Math.max(3600, Math.round(
        (new Date(params.endsAt).getTime() - new Date(params.startsAt).getTime()) / 1000
      )),
      location_type: isVirtual ? "virtual" : "in_person",
      ...(isVirtual ? {} : { in_person_location: params.location }),
    },
  };

  if (bodyContent.length > 0) {
    eventPayload.tiptap_body = {
      body: { type: "doc", content: bodyContent },
    };
  }

  const res = await fetch(`${CIRCLE_API_BASE}/api/admin/v2/events`, {
    method: 'POST',
    headers: getAdminHeaders(),
    body: JSON.stringify(eventPayload),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Circle API error creating event: ${res.status} ${text}`);
  }

  return await res.json();
}
