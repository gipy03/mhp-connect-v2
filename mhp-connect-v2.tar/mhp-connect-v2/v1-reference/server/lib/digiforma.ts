const ENDPOINT = 'https://app.digiforma.com/api/v1/graphql';

export interface DigiformaTrainee {
  id: string;
  firstname: string;
  lastname: string;
  email: string;
  phone?: string | null;
  phoneSecondary?: string | null;
  roadAddress?: string | null;
  city?: string | null;
  cityCode?: string | null;
  country?: string | null;
  countryCode?: string | null;
  birthdate?: string | null;
  nationality?: string | null;
  profession?: string | null;
  company?: { id: string; name: string } | null;
  trainingSessions?: DigiformaSession[];
}

export interface DigiformaSession {
  id: string;
  name: string;
  startDate: string | null;
  endDate: string | null;
  extranetUrl: string | null;
  place?: string | null;
  placeName?: string | null;
  remote?: boolean;
  program?: { id: string; name: string; code: string | null } | null;
  image?: { url: string; filename: string } | null;
  dates?: { date: string; startTime: string | null; endTime: string | null }[];
}

class DigiformaError extends Error {
  constructor(message: string, public details?: any) {
    super(message);
    this.name = 'DigiformaError';
  }
}

async function gql<T = any>(query: string, variables?: Record<string, any>): Promise<T | null> {
  const apiKey = process.env.DIGIFORMA_API_KEY;
  if (!apiKey) {
    throw new DigiformaError('DIGIFORMA_API_KEY is not configured');
  }

  const body: any = { query };
  if (variables) body.variables = variables;

  let res: Response;
  try {
    res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15000),
    });
  } catch (err: any) {
    if (err.name === 'TimeoutError' || err.name === 'AbortError') {
      throw new DigiformaError('DigiForma API timeout — the service may be unavailable');
    }
    throw new DigiformaError(`DigiForma API network error: ${err.message}`);
  }

  if (!res.ok) {
    if (res.status === 401) {
      throw new DigiformaError('DigiForma API authentication failed — check DIGIFORMA_API_KEY');
    }
    throw new DigiformaError(`DigiForma API returned HTTP ${res.status}`);
  }

  const data = await res.json();
  if (data.errors?.length) {
    console.error('DigiForma GraphQL errors:', JSON.stringify(data.errors));
    throw new DigiformaError('DigiForma query failed', data.errors);
  }

  return data.data as T;
}

export async function findTraineeByEmail(email: string): Promise<DigiformaTrainee | null> {
  const data = await gql<{ trainees: DigiformaTrainee[] }>(`
    query FindTrainee($email: String!) {
      trainees(filters: { email: $email }) {
        id firstname lastname email
        trainingSessions { id }
      }
    }
  `, { email });

  const matches = data?.trainees ?? [];

  if (matches.length === 0) {
    const allData = await gql<{ trainees: DigiformaTrainee[] }>(`
      query {
        trainees {
          id firstname lastname email
          trainingSessions { id }
        }
      }
    `);
    const normalizedEmail = email.toLowerCase().trim();
    const fallbackMatches = (allData?.trainees ?? []).filter(
      (t) => t.email?.toLowerCase().trim() === normalizedEmail
    );
    if (fallbackMatches.length === 0) return null;
    return fallbackMatches.find(t => (t.trainingSessions?.length ?? 0) > 0) ?? fallbackMatches[0];
  }

  return matches.find(t => (t.trainingSessions?.length ?? 0) > 0) ?? matches[0];
}

export async function findAllTraineeIdsByEmail(email: string): Promise<string[]> {
  const data = await gql<{ trainees: DigiformaTrainee[] }>(`
    query FindTrainee($email: String!) {
      trainees(filters: { email: $email }) {
        id email
      }
    }
  `, { email });

  const matches = data?.trainees ?? [];
  if (matches.length > 0) return matches.map(t => String(t.id));

  const allData = await gql<{ trainees: DigiformaTrainee[] }>(`
    query { trainees { id email } }
  `);
  const normalizedEmail = email.toLowerCase().trim();
  return (allData?.trainees ?? [])
    .filter(t => t.email?.toLowerCase().trim() === normalizedEmail)
    .map(t => String(t.id));
}

export async function getTraineeWithSessions(digiformaId: string): Promise<DigiformaTrainee | null> {
  if (!/^\d+$/.test(digiformaId)) {
    console.error('Invalid DigiForma ID (non-numeric):', digiformaId);
    return null;
  }

  const data = await gql<{ trainee: DigiformaTrainee }>(`
    query GetTrainee($id: ID!) {
      trainee(id: $id) {
        id firstname lastname email
        company { id name }
        trainingSessions {
          id name startDate endDate extranetUrl
          place placeName remote
          program { id name code }
          image { url filename }
          dates { date startTime endTime }
        }
      }
    }
  `, { id: digiformaId });

  return data?.trainee ?? null;
}

const extranetCache = new Map<string, { url: string | null; timestamp: number }>();
const EXTRANET_CACHE_TTL = 10 * 60 * 1000;

export async function getExtranetUrl(email: string): Promise<string | null> {
  const cacheKey = email.toLowerCase().trim();
  const cached = extranetCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < EXTRANET_CACHE_TTL) {
    return cached.url;
  }

  try {
    const data = await gql<{ customers: Array<{ customerTrainees: Array<{ extranetUrl: string | null; trainee?: { id: string; email: string } }> }> }>(`
      query {
        customers {
          customerTrainees {
            extranetUrl
            trainee { id email }
          }
        }
      }
    `);

    if (!data?.customers) {
      extranetCache.set(cacheKey, { url: null, timestamp: Date.now() });
      return null;
    }

    const normalizedEmail = cacheKey;

    for (const customer of data.customers) {
      for (const ct of customer.customerTrainees ?? []) {
        if (ct.extranetUrl && ct.trainee?.email?.toLowerCase().trim() === normalizedEmail) {
          extranetCache.set(cacheKey, { url: ct.extranetUrl, timestamp: Date.now() });
          return ct.extranetUrl;
        }
      }
    }

    extranetCache.set(cacheKey, { url: null, timestamp: Date.now() });
    return null;
  } catch (err: any) {
    if (err?.details?.some?.((e: any) => e?.message?.includes?.('trainee'))) {
      console.warn("getExtranetUrl: 'trainee' field not available on customerTrainees, trying without it");
      try {
        const fallback = await gql<{ customers: Array<{ customerTrainees: Array<{ extranetUrl: string | null }> }> }>(`
          query {
            customers {
              customerTrainees {
                extranetUrl
              }
            }
          }
        `);
        if (fallback?.customers) {
          for (const customer of fallback.customers) {
            for (const ct of customer.customerTrainees ?? []) {
              if (ct.extranetUrl) {
                extranetCache.set(cacheKey, { url: ct.extranetUrl, timestamp: Date.now() });
                return ct.extranetUrl;
              }
            }
          }
        }
      } catch {}
    }
    console.error("getExtranetUrl error:", err);
    extranetCache.set(cacheKey, { url: null, timestamp: Date.now() });
    return null;
  }
}

export async function getAllTrainees(): Promise<DigiformaTrainee[]> {
  const data = await gql<{ trainees: DigiformaTrainee[] }>(`
    query {
      trainees {
        id firstname lastname email
        phone phoneSecondary
        roadAddress city cityCode
        country countryCode
        birthdate nationality profession
      }
    }
  `);
  return data?.trainees ?? [];
}

export interface DigiformaProgram {
  id: string;
  name: string;
  code: string | null;
  description: string | null;
  subtitle: string | null;
  durationInDays: number | null;
  durationInHours: number | null;
  duration: string | null;
  image: { url: string; filename: string } | null;
  goals: { text: string }[] | null;
  steps: { text: string; substeps: { text: string }[] }[] | null;
  assessments: { text: string }[] | null;
  costs: { cost: number }[] | null;
  capacity: { active: boolean; max: number | null; min: number | null } | null;
  satisfactionRate: { evaluationsCount: number; score: number } | null;
  category: { id: string; name: string } | null;
  certificationModality: string | null;
  certificationDetails: string | null;
  admissionModality: string | null;
  trainingModality: string | null;
  handicappedAccessibility: string | null;
  graduationModality: string | null;
  graduationTarget: string | null;
  version: number | null;
}

export async function getAllPrograms(): Promise<DigiformaProgram[]> {
  const data = await gql<{ programs: DigiformaProgram[] }>(`
    query {
      programs(filters: { rootLevelOnly: true }) {
        id name code description subtitle
        durationInDays durationInHours duration
        image { url filename }
        goals { text }
        steps { text substeps { text } }
        assessments { text }
        costs { cost }
        capacity { active max min }
        satisfactionRate { evaluationsCount score }
        category { id name }
        certificationModality certificationDetails
        admissionModality trainingModality
        handicappedAccessibility
        graduationModality graduationTarget
        version
      }
    }
  `);
  return data?.programs ?? [];
}

export async function createTrainee(params: {
  firstname: string;
  lastname: string;
  email: string;
  phone?: string;
  roadAddress?: string;
  city?: string;
  cityCode?: string;
  countryCode?: string;
  birthdate?: string;
  nationality?: string;
  profession?: string;
}): Promise<DigiformaTrainee> {
  const data = await gql<{ createTrainee: DigiformaTrainee }>(`
    mutation CreateTrainee($input: TraineeInput!) {
      createTrainee(traineeInput: $input) {
        id firstname lastname email
      }
    }
  `, {
    input: {
      firstname: params.firstname,
      lastname: params.lastname,
      email: params.email,
      phone: params.phone || null,
      roadAddress: params.roadAddress || null,
      city: params.city || null,
      cityCode: params.cityCode || null,
      countryCode: params.countryCode || null,
      birthdate: params.birthdate || null,
      nationality: params.nationality || null,
      profession: params.profession || null,
    },
  });
  if (!data?.createTrainee) {
    throw new DigiformaError('Failed to create trainee in DigiForma');
  }
  return data.createTrainee;
}

export async function addDraftTraineeToSession(
  traineeId: string,
  trainingSessionId: string
): Promise<{ id: string }> {
  const data = await gql<{ createDraftSessionTrainee: { trainee: { id: string } } }>(`
    mutation AddDraftTrainee($input: DraftSessionTraineeInput!, $sessionId: ID!) {
      createDraftSessionTrainee(draftSessionTraineeInput: $input, trainingSessionId: $sessionId) {
        trainee {
          id
        }
      }
    }
  `, {
    input: { traineeId },
    sessionId: trainingSessionId,
  });
  if (!data?.createDraftSessionTrainee?.trainee) {
    throw new DigiformaError('Failed to add trainee to training session');
  }
  return data.createDraftSessionTrainee.trainee;
}

export interface DigiformaCalendarSession {
  id: string;
  name: string;
  code: string | null;
  startDate: string | null;
  endDate: string | null;
  place: string | null;
  placeName: string | null;
  remote: boolean;
  inter: boolean;
  program: { id: string; name: string; code: string | null } | null;
  image: { url: string; filename: string } | null;
  dates: { date: string; startTime: string | null; endTime: string | null }[];
}

export async function getAllTrainingSessions(): Promise<DigiformaCalendarSession[]> {
  const data = await gql<{ trainingSessions: DigiformaCalendarSession[] }>(`
    query {
      trainingSessions {
        id name code startDate endDate
        place placeName remote inter
        program { id name code }
        image { url filename }
        dates { date startTime endTime }
      }
    }
  `);
  return data?.trainingSessions ?? [];
}

export { DigiformaError };
