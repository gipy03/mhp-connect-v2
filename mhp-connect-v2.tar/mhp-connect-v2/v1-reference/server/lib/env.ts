import { z } from "zod";

const envSchema = z.object({
  DATABASE_URL: z.string().min(1),
  SESSION_SECRET: z.string().min(1),
  SMTP_USER: z.string().email().optional(),
  SMTP_APP_PASSWORD: z.string().optional(),
  DIGIFORMA_API_KEY: z.string().optional(),
  CIRCLE_API_TOKEN: z.string().optional(),
  CIRCLE_COMMUNITY_URL: z.string().optional(),
  BEXIO_API_TOKEN: z.string().optional(),
  GOOGLE_GEOCODING_API_KEY: z.string().optional(),
  GOOGLE_CLIENT_ID: z.string().optional(),
  GOOGLE_CLIENT_SECRET: z.string().optional(),
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.string().default("5000"),
  OUTSETA_DOMAIN: z.string().optional(),
});

export type Env = z.infer<typeof envSchema>;

export function validateEnv(): Env {
  const result = envSchema.safeParse(process.env);

  if (!result.success) {
    console.error("Environment validation failed. Missing or invalid variables:");
    const missingVars = Object.keys(result.error.flatten().fieldErrors);
    missingVars.forEach((key) => {
      console.error(`  - ${key}`);
    });
    process.exit(1);
  }

  if (result.data.NODE_ENV !== "production") {
    console.log("=== mhp | connect ===");
    console.log(`Environment: ${result.data.NODE_ENV}`);
    console.log(`SMTP: ${result.data.SMTP_USER ? "configured" : "not configured"}`);
    console.log(`Bexio: ${result.data.BEXIO_API_TOKEN ? "configured" : "not configured"}`);
    console.log(`Geocoding: ${result.data.GOOGLE_GEOCODING_API_KEY ? "configured" : "not configured"}`);
    console.log(`Google Auth: ${result.data.GOOGLE_CLIENT_ID ? "configured" : "not configured"}`);
    console.log("=====================");
  }

  return result.data;
}

export const env = validateEnv();
